# 3.2.2 (2015-12-14)

  * upgrade in-viewport

# 3.2.1 (2015-06-03)

  * upgrade in-viewport, no new feature

# 3.2.0 (2015-05-24)

  * upgrade in-viewport, fixes children in hidden parent case

# 3.1.0 (2015-05-23)

  * feat: upgrade in-viewport to 3.1.0, checks element is visible before triggering callback

# 3.0.2 (2015-03-14)

  * upgrade all deps

# 3.0.1 (2015-03-12)
  
  * switch to closurecompiler

# 3.0.0 (2015-01-30)

  * refactor using browserify


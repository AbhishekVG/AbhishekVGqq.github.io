require('./carousel.css');
module.exports = require('./index-nocss.js');
